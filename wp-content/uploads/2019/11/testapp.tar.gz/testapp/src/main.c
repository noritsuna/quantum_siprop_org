#include <stdio.h>
#include "QuEST.h"

int main (int narg, char *varg[]) {

    QuESTEnv env = createQuESTEnv();
    Qureg qubits = createQureg(4, env);
    initZeroState(qubits);

    for (int i = 0; i < 10000000; i++) {
      hadamard(qubits, 0);
      int outcome = measure(qubits, 0);
    }

    destroyQureg(qubits, env); 
    destroyQuESTEnv(env);

    return 0;
}